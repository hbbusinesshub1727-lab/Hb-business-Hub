# HB Business Hub Pro V4

Premium gift ecommerce + full admin panel.

## Included
- Customer signup/login and account session
- Admin notifications
- Product CSV export
- FAQ page
- GST number field on orders
- No online payment gateway (intentionally excluded)
- Premium responsive Amazon-inspired storefront
- Product search, category filters, price filters, sorting
- Product detail modal/page
- Multiple product image URLs
- Wishlist
- Cart
- WhatsApp checkout with customer details
- Reviews and ratings
- Coupons
- Flash deals / featured products
- Festival/offer banner
- Product variants
- Stock / low-stock indicators
- Product CRUD and category CRUD
- Orders and status management
- Customer list
- Sales dashboard and reports
- Invoice print
- Homepage settings
- WhatsApp settings
- SEO settings
- Admin password change
- CSV product export/import
- About / Contact / Privacy / Terms pages
- PWA manifest
- SQLite persistence

## Start
Node.js 18+ required.

npm install
npm start

Customer: http://localhost:3000
Admin: http://localhost:3000/admin

Default admin:
Hiren
hiren@1727

Change the password after first login.
Set your real WhatsApp number in Admin > Settings.
