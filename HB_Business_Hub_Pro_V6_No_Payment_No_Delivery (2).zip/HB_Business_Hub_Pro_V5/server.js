const express=require("express"),session=require("express-session"),bcrypt=require("bcryptjs"),multer=require("multer"),path=require("path"),fs=require("fs"),Database=require("better-sqlite3");
const app=express(),PORT=process.env.PORT||3000,db=new Database("hb_business_hub.db");
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY,name TEXT UNIQUE,password_hash TEXT);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT UNIQUE,password_hash TEXT,email TEXT,address TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,type TEXT,message TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,description TEXT,category_id INTEGER,price REAL,discount REAL DEFAULT 0,stock INTEGER DEFAULT 0,image TEXT,images TEXT DEFAULT '[]',variants TEXT DEFAULT '[]',featured INTEGER DEFAULT 0,flash INTEGER DEFAULT 0,rating REAL DEFAULT 0,reviews INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_name TEXT,phone TEXT,address TEXT,items TEXT,total REAL,coupon TEXT DEFAULT '',status TEXT DEFAULT 'New',gst_number TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,name TEXT,rating INTEGER,comment TEXT,approved INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS coupons(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,discount REAL,type TEXT DEFAULT 'percent',active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
`);
if(!db.prepare("SELECT 1 FROM admins LIMIT 1").get()) db.prepare("INSERT INTO admins(name,password_hash) VALUES(?,?)").run(process.env.ADMIN_NAME||"Hiren",bcrypt.hashSync(process.env.ADMIN_PASSWORD||"hiren@1727",10));
const defaults={store_name:"HB Business Hub",whatsapp_number:process.env.WHATSAPP_NUMBER||"91XXXXXXXXXX",offer_text:"🎁 Special Gifts • Best Prices",hero_title:"Beautiful Gifts, Better Prices",hero_subtitle:"Birthday • Anniversary • Home Decor • Corporate Gifts",currency:"₹",seo_title:"HB Business Hub | Premium Gifts",seo_description:"Shop premium gifts at HB Business Hub"};
for(const [k,v] of Object.entries(defaults))db.prepare("INSERT OR IGNORE INTO settings VALUES(?,?)").run(k,v);
for(const c of ["Birthday Gifts","Anniversary","Home Decor","Corporate Gifts","Kids Gifts","Festival Gifts"])db.prepare("INSERT OR IGNORE INTO categories(name) VALUES(?)").run(c);
const uploadDir=path.join(__dirname,"public/uploads");fs.mkdirSync(uploadDir,{recursive:true});
const upload=multer({storage:multer.diskStorage({destination:uploadDir,filename:(r,f,cb)=>cb(null,Date.now()+"-"+f.originalname.replace(/[^a-z0-9._-]/gi,"_"))})});
app.use(express.json({limit:"10mb"}));app.use(express.urlencoded({extended:true}));app.use(session({secret:process.env.SESSION_SECRET||"hb-pro-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax"}}));app.use(express.static("public"));
const auth=(r,s,n)=>r.session.admin?n():s.status(401).json({error:"Unauthorized"});
app.post("/api/login",(r,s)=>{let a=db.prepare("SELECT * FROM admins WHERE name=?").get(r.body.name);if(!a||!bcrypt.compareSync(r.body.password,a.password_hash))return s.status(401).json({error:"Invalid login"});r.session.admin={id:a.id,name:a.name};s.json({ok:true})});
app.post("/api/logout",(r,s)=>r.session.destroy(()=>s.json({ok:true})));app.get("/api/me",(r,s)=>s.json({admin:r.session.admin||null}));
app.get("/api/store",(r,s)=>{let settings=Object.fromEntries(db.prepare("SELECT * FROM settings").all().map(x=>[x.key,x.value]));let products=db.prepare("SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC").all();let categories=db.prepare("SELECT * FROM categories ORDER BY name").all();let coupons=db.prepare("SELECT * FROM coupons WHERE active=1").all();s.json({settings,products,categories,coupons})});
app.post("/api/products",auth,upload.single("image"),(r,s)=>{let x=r.body,img=r.file?"/uploads/"+r.file.filename:(x.image||"");let q=db.prepare("INSERT INTO products(name,description,category_id,price,discount,stock,image,images,variants,featured,flash) VALUES(?,?,?,?,?,?,?,?,?,?,?)").run(x.name,x.description||"",x.category_id||null,+x.price||0,+x.discount||0,+x.stock||0,img,x.images||"[]",x.variants||"[]",+x.featured||0,+x.flash||0);s.json({id:q.lastInsertRowid})});
app.put("/api/products/:id",auth,upload.single("image"),(r,s)=>{let old=db.prepare("SELECT * FROM products WHERE id=?").get(r.params.id),x=r.body,img=r.file?"/uploads/"+r.file.filename:(x.image??old.image);db.prepare("UPDATE products SET name=?,description=?,category_id=?,price=?,discount=?,stock=?,image=?,images=?,variants=?,featured=?,flash=? WHERE id=?").run(x.name,x.description||"",x.category_id||null,+x.price||0,+x.discount||0,+x.stock||0,img,x.images||"[]",x.variants||"[]",+x.featured||0,+x.flash||0,r.params.id);s.json({ok:true})});
app.delete("/api/products/:id",auth,(r,s)=>{db.prepare("DELETE FROM products WHERE id=?").run(r.params.id);s.json({ok:true})});
app.post("/api/categories",auth,(r,s)=>{try{s.json(db.prepare("INSERT INTO categories(name) VALUES(?)").run(r.body.name))}catch(e){s.status(400).json({error:"Category exists"})}});
app.delete("/api/categories/:id",auth,(r,s)=>{db.prepare("DELETE FROM categories WHERE id=?").run(r.params.id);s.json({ok:true})});
app.get("/api/orders",auth,(r,s)=>s.json(db.prepare("SELECT * FROM orders ORDER BY id DESC").all()));
app.post("/api/orders",(r,s)=>{
 let x=r.body,c=r.session.customer,name=c?c.name:x.customer_name,phone=c?c.phone:x.phone;
 let q=db.prepare("INSERT INTO orders(customer_name,phone,address,items,total,coupon,gst_number) VALUES(?,?,?,?,?,?,?)").run(name,phone,x.address||"",JSON.stringify(x.items||[]),+x.total||0,x.coupon||"",x.gst_number||"");
 db.prepare("INSERT INTO notifications(order_id,type,message) VALUES(?,?,?)").run(q.lastInsertRowid,"order","New order received");
 s.json({id:q.lastInsertRowid});
});
app.put("/api/orders/:id",auth,(r,s)=>{db.prepare("UPDATE orders SET status=? WHERE id=?").run(r.body.status,r.params.id);s.json({ok:true})});
app.get("/api/reviews/:id",(r,s)=>s.json(db.prepare("SELECT * FROM reviews WHERE product_id=? AND approved=1 ORDER BY id DESC").all(r.params.id)));
app.post("/api/reviews",(r,s)=>{let x=r.body;db.prepare("INSERT INTO reviews(product_id,name,rating,comment) VALUES(?,?,?,?)").run(x.product_id,x.name,x.rating,x.comment);let a=db.prepare("SELECT AVG(rating) avg,COUNT(*) c FROM reviews WHERE product_id=? AND approved=1").get(x.product_id);db.prepare("UPDATE products SET rating=?,reviews=? WHERE id=?").run(a.avg||0,a.c,x.product_id);s.json({ok:true})});
app.get("/api/customers",auth,(r,s)=>s.json(db.prepare("SELECT customer_name,phone,COUNT(*) orders,MAX(created_at) last_order,SUM(total) spent FROM orders GROUP BY phone ORDER BY spent DESC").all()));
app.get("/api/dashboard",auth,(r,s)=>s.json({products:db.prepare("SELECT COUNT(*) c FROM products").get().c,orders:db.prepare("SELECT COUNT(*) c FROM orders").get().c,sales:db.prepare("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status!='Cancelled'").get().s,customers:db.prepare("SELECT COUNT(DISTINCT phone) c FROM orders").get().c}));
app.post("/api/coupons",auth,(r,s)=>{try{s.json(db.prepare("INSERT INTO coupons(code,discount,type,active) VALUES(?,?,?,1)").run(r.body.code.toUpperCase(),+r.body.discount,r.body.type||"percent"))}catch(e){s.status(400).json({error:"Coupon exists"})}});
app.delete("/api/coupons/:id",auth,(r,s)=>{db.prepare("DELETE FROM coupons WHERE id=?").run(r.params.id);s.json({ok:true})});
app.put("/api/settings",auth,(r,s)=>{for(const [k,v] of Object.entries(r.body))db.prepare("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(k,String(v));s.json({ok:true})});
app.put("/api/admin/password",auth,(r,s)=>{let a=db.prepare("SELECT * FROM admins WHERE id=?").get(r.session.admin.id);if(!bcrypt.compareSync(r.body.oldPassword,a.password_hash))return s.status(400).json({error:"Old password incorrect"});db.prepare("UPDATE admins SET password_hash=? WHERE id=?").run(bcrypt.hashSync(r.body.newPassword,10),a.id);s.json({ok:true})});

app.post("/api/customer/register",(r,s)=>{
 const x=r.body;if(!x.name||!x.phone||!x.password)return s.status(400).json({error:"Name, phone and password required"});
 try{const q=db.prepare("INSERT INTO customers(name,phone,password_hash,email,address) VALUES(?,?,?,?,?)").run(x.name,x.phone,bcrypt.hashSync(x.password,10),x.email||"",x.address||"");r.session.customer={id:q.lastInsertRowid,name:x.name,phone:x.phone};s.json({ok:true})}
 catch(e){s.status(400).json({error:"Phone already registered"})}
});
app.post("/api/customer/login",(r,s)=>{
 const x=r.body,c=db.prepare("SELECT * FROM customers WHERE phone=?").get(x.phone);
 if(!c||!bcrypt.compareSync(x.password,c.password_hash))return s.status(401).json({error:"Invalid customer login"});
 r.session.customer={id:c.id,name:c.name,phone:c.phone};s.json({ok:true,name:c.name});
});
app.post("/api/customer/logout",(r,s)=>{r.session.customer=null;s.json({ok:true})});
app.get("/api/customer/me",(r,s)=>s.json({customer:r.session.customer||null}));
app.get("/api/customer/orders",(r,s)=>{
 if(!r.session.customer)return s.status(401).json({error:"Login required"});
 s.json(db.prepare("SELECT * FROM orders WHERE phone=? ORDER BY id DESC").all(r.session.customer.phone));
});
app.get("/api/notifications",auth,(r,s)=>s.json(db.prepare("SELECT * FROM notifications ORDER BY id DESC LIMIT 100").all()));
app.get("/api/customers",auth,(r,s)=>s.json(db.prepare("SELECT customer_name,phone,COUNT(*) orders,MAX(created_at) last_order,SUM(total) spent FROM orders GROUP BY phone ORDER BY spent DESC").all()));
app.get("/api/products.csv",auth,(r,s)=>{
 const rows=db.prepare("SELECT p.id,p.name,c.name category,p.price,p.discount,p.stock,p.rating,p.reviews,p.featured,p.flash FROM products p LEFT JOIN categories c ON c.id=p.category_id").all();
 const esc=v=>`"${String(v??"").replace(/"/g,'""')}"`;
 s.setHeader("Content-Type","text/csv");s.setHeader("Content-Disposition","attachment; filename=hb-products.csv");
 s.send("id,name,category,price,discount,stock,rating,reviews,featured,flash\n"+rows.map(x=>Object.values(x).map(esc).join(",")).join("\n"));
});
app.get("/admin",(r,s)=>s.sendFile(path.join(__dirname,"public/admin/index.html")));

app.listen(PORT,()=>console.log("HB Business Hub Pro running on http://localhost:"+PORT));
